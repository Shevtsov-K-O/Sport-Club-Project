<?php
global $conn;
$conn = mysqli_connect("127.0.0.1", "root", "Ababa1234$", "SportClub");
if ($conn->connect_error) {
    error_log('Connection error: ' . $conn->connect_error);
}
?>
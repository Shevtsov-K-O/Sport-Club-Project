<?php
    setcookie("usernamecookie", $dbusername, time() + 6000);
    setcookie("userlevelcookie", $dbuserlevel, time() + 6000);
?>
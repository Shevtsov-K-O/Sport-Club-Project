<?php 
if('admin' != $_COOKIE["userlevelcookie"]){
    header("Location: intropage.php");
}
?>
<?php
if(isset($_POST["id"]))
{
    include "connect.php";
    if (!$conn) {
      die("Error: " . mysqli_connect_error());
    }
    $matches = mysqli_real_escape_string($conn, $_POST["id"]);
    $sql = "DELETE FROM matches WHERE id = '$matches'";
    if(mysqli_query($conn, $sql)){
         
        header("Location: matches.php");
    } else{
        echo "Error: " . mysqli_error($conn);
    }
    mysqli_close($conn);    
}
?>
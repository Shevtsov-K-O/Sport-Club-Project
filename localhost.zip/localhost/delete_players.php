<?php 
if('admin' != $_COOKIE["userlevelcookie"]){
    header("Location: intropage.php");
}
?>
<?php
if(isset($_POST["id"]))
{
    include "connect.php";
    if (!$conn) {
      die("Error: " . mysqli_connect_error());
    }
    $playersid = mysqli_real_escape_string($conn, $_POST["id"]);
    $sql = "DELETE FROM players WHERE id = '$playersid'";
    if(mysqli_query($conn, $sql)){
         
        header("Location: players.php");
    } else{
        echo "Error: " . mysqli_error($conn);
    }
    mysqli_close($conn);    
}
?>
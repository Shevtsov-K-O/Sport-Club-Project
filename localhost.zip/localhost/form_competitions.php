<?php 
if('admin' != $_COOKIE["userlevelcookie"]){
    header("Location: intropage.php");
}
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="css/base.css">
<?php include("font.php"); ?>
<title>Inserting...</title>
<meta charset="utf-8" />
</head>
<body>
    <div class="divbg">
        <div class="regform">
            <h2>Add competitions</h2>
            <form action="insert_competitions.php" method="post">
            <p>Name:</p>
                <p><input type="text" name="name" /></p>
                <p>Location(Country, city):</p> 
               <p><input type="text" name="location" /></p>
                <p>Start date (yyyy-mm-dd):</p>
                <p><input type="text" name="start_date" /></p>
                <p>End date (yyyy-mm-dd):</p>
                <p><input type="text" name="end_date" /></p>
               <p>Level(amateur, semi-pro, pro):</p> 
               <p><input type="text" name="level" /></p>
                <p><input type="submit" class="button" value="Add"></p>
            </form>
        </div>
    </div>
</body>
</html>
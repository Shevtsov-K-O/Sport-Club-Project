<?php 
if('admin' != $_COOKIE["userlevelcookie"]){
    header("Location: intropage.php");
}
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="css/base.css">
<?php include("font.php"); ?>
<title>inserting...</title>
<meta charset="utf-8" />
</head>
<body>
    <div class="divbg">
        <div class="regform">
            <h2>Add match</h2>
            <form action="insert_matches.php" method="post">
            <p>Date and time (yyyy-mm-dd hh:mm:ss):</p>
                <p><input type="text" name="date_time" /></p>
                <p>Location (Stadium):</p>
                <p><input type="text" name="location" /></p>
                <p>Competition ID:</p>
                <p><input type="number" name="competition_id" /></p>
                <p>Home-team ID:</p>
                <p><input type="number" name="home_team_id" /></p>
                <p>Away-team ID:</p>
                <p><input type="number" name="away_team_id" /></p>
                <p>Home-team score:</p>
                <p><input type="number" name="home_score" /></p>
                <p>Away-team score:</p>
                <p><input type="number" name="away_score" /></p>
                <p><input type="submit" class="button" value="Add"></p>
            </form>
        </div>
    </div>
</body>
</html>
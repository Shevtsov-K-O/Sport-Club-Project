<?php 
if('admin' != $_COOKIE["userlevelcookie"]){
    header("Location: intropage.php");
}
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="css/base.css">
<?php include("font.php"); ?>
<title>Inserting...</title>
<meta charset="utf-8" />
</head>
<body>
    <div class="divbg">
        <div class="regform">
            <h2>Add player</h2>
            <form action="insert_players.php" method="post">
                <p>First Name:</p>
                <p><input type="text" name="first_name" /></p>
                <p>Last Name:</p>
                <p><input type="text" name="last_name" /></p>
                <p>Gender (m, f):</p>
                <p><input type="text" name="gender" /></p>
                <p>Birth_Date (yyyy-mm-dd):</p>
                <p><input type="text" name="birth_date" /></p>
                <p>Position:</p>
                <p><input type="text" name="position" /></p>
                <p>Team ID:</p>
                <p><input type="number" name="team_id" /></p>
                <p><input type="submit" class="button" value="Add"></p>
            </form>
        </div>
    </div>
</body>
</html>
<?php 
if('admin' != $_COOKIE["userlevelcookie"]){
    header("Location: intropage.php");
}
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="css/base.css">
<?php include("font.php"); ?>
<title>Inserting...</title>
<meta charset="utf-8" />
</head>
<body>
    <div class="divbg">
        <div class="regform">
            <h2>Add team</h2>
            <form action="insert_teams.php" method="post">
                <p>Name:</p>
                <p><input type="text" name="name" /></p>
                <p>City:</p>
                <p><input type="text" name="city" /></p>
                <p>Country:</p>
                <p><input type="text" name="country" /></p>
                <p>Level(amateur, semi-pro, pro):</p> 
                <p><input type="text" name="level" /></p>
                <p>Coach ID:</p>
                <p><input type="number" name="coach_id" /></p>
                <p><input type="submit" class="button" value="Add"></p>
            </form>
        </div>
    </div>
</body>
</html>
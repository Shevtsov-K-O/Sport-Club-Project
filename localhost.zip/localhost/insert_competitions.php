<?php 
if('admin' != $_COOKIE["userlevelcookie"]){
    header("Location: intropage.php");
}
?>
<?php
if (isset($_POST["name"]) && isset($_POST["location"]) && isset($_POST["start_date"]) && isset($_POST["end_date"]) && isset($_POST["level"])) {   
    include "connect.php";
    if (!$conn) {
      die("Error: " . mysqli_connect_error());
    }
    $name = mysqli_real_escape_string($conn, $_POST["name"]);
    $location = mysqli_real_escape_string($conn, $_POST["location"]);
    $sdate = mysqli_real_escape_string($conn, $_POST["start_date"]);
    $edate = mysqli_real_escape_string($conn, $_POST["end_date"]);
    $level = mysqli_real_escape_string($conn, $_POST["level"]);
    $sql = "INSERT INTO competitions (name, location, start_date, end_date, level) VALUES ('$name', '$location', '$sdate', '$edate', '$level')";
        if(mysqli_query($conn, $sql)){
            header("Location: index.php");
    } else{
        echo "Error: " . mysqli_error($conn);
    }
    mysqli_close($conn);
}
?>
<?php 
if('admin' != $_COOKIE["userlevelcookie"]){
    header("Location: intropage.php");
}
?>
<?php
if (isset($_POST["date_time"]) && isset($_POST["location"]) && isset($_POST["competition_id"]) && isset($_POST["home_team_id"]) && isset($_POST["away_team_id"]) && isset($_POST["home_score"]) && isset($_POST["away_score"])) {
    include "connect.php";
    if (!$conn) {
      die("Error: " . mysqli_connect_error());
    }
    $date = mysqli_real_escape_string($conn, $_POST["date_time"]);
    $location = mysqli_real_escape_string($conn, $_POST["location"]);
    $cid = mysqli_real_escape_string($conn, $_POST["competition_id"]);
    $hid = mysqli_real_escape_string($conn, $_POST["home_team_id"]);
    $aid = mysqli_real_escape_string($conn, $_POST["away_team_id"]);
    $hscore = mysqli_real_escape_string($conn, $_POST["home_score"]);
    $ascore = mysqli_real_escape_string($conn, $_POST["away_score"]);
    $sql = "INSERT INTO matches (date_time, location, competition_id, home_team_id, away_team_id, home_score, away_score) VALUES ('$date', '$location', $cid, $hid, $aid, $hscore, $ascore)";
        if(mysqli_query($conn, $sql)){
            header("Location: matches.php");
    } else{
        echo "Error: " . mysqli_error($conn);
    }
    mysqli_close($conn);
}
?>
<?php 
if('admin' != $_COOKIE["userlevelcookie"]){
    header("Location: intropage.php");
}
?>
<?php
if (isset($_POST["first_name"]) && isset($_POST["last_name"])&& isset($_POST["gender"])&& isset($_POST["birth_date"])&& isset($_POST["position"])&& isset($_POST["team_id"])) {
    include "connect.php";
    if (!$conn) {
      die("Error: " . mysqli_connect_error());
    }
    $fname = mysqli_real_escape_string($conn, $_POST["first_name"]);
    $lname = mysqli_real_escape_string($conn, $_POST["last_name"]);
    $gender = mysqli_real_escape_string($conn, $_POST["gender"]);
    $birth_date = mysqli_real_escape_string($conn, $_POST["birth_date"]);
    $position = mysqli_real_escape_string($conn, $_POST["position"]);
    $tid = mysqli_real_escape_string($conn, $_POST["team_id"]);
    $sql = "INSERT INTO players (first_name, last_name, gender, birth_date, position, team_id) VALUES ('$fname', '$lname', '$gender', '$birth_date', '$position', $tid)";
        if(mysqli_query($conn, $sql)){
            header("Location: players.php");
    } else{
        echo "Error: " . mysqli_error($conn);
    }
    mysqli_close($conn);
}
?>
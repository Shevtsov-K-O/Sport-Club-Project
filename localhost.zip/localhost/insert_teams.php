<?php 
if('admin' != $_COOKIE["userlevelcookie"]){
    header("Location: intropage.php");
}
?>
<?php
if (isset($_POST["name"]) && isset($_POST["city"]) && isset($_POST["country"]) && isset($_POST["level"]) && isset($_POST["coach_id"])) {
    include "connect.php";
    if (!$conn) {
      die("Error: " . mysqli_connect_error());
    }
    $name = mysqli_real_escape_string($conn, $_POST["name"]);
    $city = mysqli_real_escape_string($conn, $_POST["city"]);
    $country = mysqli_real_escape_string($conn, $_POST["country"]);
    $level = mysqli_real_escape_string($conn, $_POST["level"]);
    $coach_id = mysqli_real_escape_string($conn, $_POST["coach_id"]);
    $sql = "INSERT INTO teams (name, city, country, level, coach_id) VALUES ('$name', '$city', '$country', '$level', $coach_id)";
        if(mysqli_query($conn, $sql)){
            header("Location: teams.php");
    } else{
        echo "Error: " . mysqli_error($conn);
    }
    mysqli_close($conn);
}
?>
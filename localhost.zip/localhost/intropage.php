<?php
			session_start();
			if(!isset($_SESSION["session_username"])):
				header("location:login.php");
			else:
		?>
<!DOCTYPE html>
<html>
	<head>
	<?php include("font.php"); ?>
		<title>Zoo</title>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="css/base.css">
	</head>
	<body>
		<div class="divbg">
		<h2>Welcome, <?php echo $_SESSION['session_username'];?>!</h2>
  		<table>
			<th><a href="logout.php">Logout from system</a></th>
		</table>
		<h3 class="hehe">Choose table to work with:</h3>
  		<table>
  			<th><a href="index.php">Competitions </a></th>
  			<th><a href="matches.php">Matches </a></th>
  			<th><a href="players.php">Players </a></th>
			  <th><a href="teams.php">Teams</a></th>
  		</table>
		</div>
		<div><p style="text-align:center;"><img src="img/istockphoto-164554023-612x612.jpg" alt="Logo"></p></div>
	</body>
</html>
<?php
	endif;
?>
<!DOCTYPE html>
<html>
<head>
<?php include("font.php"); ?>
<title>Matches</title>
<meta charset="utf-8" />
<link rel="stylesheet" href="css/base.css">
</head>
<body>
<div class="divbgbd">
<h2>List of matches</h2>
<table>
    <tr>
    <th><a href="index.php">Competitions</a></th>
        <th><a href="players.php">Players</a></th>
        <th><a href="teams.php">Teams</a></th>
        <th><?php echo $_COOKIE["usernamecookie"];?></th>
        <th><a href="logout.php">Log out</a></th>
    </tr>
</table>
<?php
include "connect.php";
if($conn->connect_error){
    die("Error: " . $conn->connect_error);
}
$sql = "SELECT * FROM matches";
if($result = $conn->query($sql)){
    $rowsCount = $result->num_rows;
    echo "<p>Rows: $rowsCount</p>";
    echo "<table><tr><th>ID</th><th>Date</th><th>Location</th><th>Competition_id</th><th>Home_team_id</th><th>Away_team_id</th><th>Home_score</th><th>Away_score</th><th></th><th></th></tr>";
    foreach($result as $row){
        echo "<tr>";
            echo "<td>" . $row["id"] . "</td>";
            echo "<td>" . $row["date_time"] . "</td>";
            echo "<td>" . $row["location"] . "</td>";
            echo "<td>" . $row["competition_id"] . "</td>";
            echo "<td>" . $row["home_team_id"] . "</td>";
            echo "<td>" . $row["away_team_id"] . "</td>";
            echo "<td>" . $row["home_score"] . "</td>";
            echo "<td>" . $row["away_score"] . "</td>";
            if('admin' == $_COOKIE["userlevelcookie"]){
            echo "<td><a href='update_matches.php?id=" . $row["id"] . "'>Change</a></td>";
            echo "<td><form action='delete_matches.php' method='post'>
                        <input type='hidden' name='id' value='" . $row["id"] . "' />
                        <input type='submit' class='button' value='Delete'>
                   </form></td>";
            } else {
                echo "<td></td>";
                echo "<td></td>";
            }
        echo "</tr>";
    }
    echo "</table>";
    $result->free();
} else{
    echo "Error: " . $conn->error;
}
$conn->close();
if('admin' == $_COOKIE["userlevelcookie"])
echo "<table>
    <tr>
        <th><a href='form_matches.php'>Add new match</a></th>
    </tr>
</table>"
?>
</div>
</body>
</html>
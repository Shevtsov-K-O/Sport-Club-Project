<?php
if ('admin' != $_COOKIE["userlevelcookie"]) {
    header("Location: intropage.php");
}
?>
<!DOCTYPE html>
<html>
<head>
<?php include("font.php"); ?>
<title>Players</title>
<meta charset="utf-8" />
<link rel="stylesheet" href="css/base.css">
</head>
<body>
<div class="divbgbd">
<h2>List of players</h2>
<table>
    <tr>
    <th><a href="index.php">Competitions</a></th>
        <th><a href="matchess.php">Matches</a></th>
        <th><a href="teams.php">Teams</a></th>
        <th><?php echo $_COOKIE["usernamecookie"];?></th>
        <th><a href="logout.php">Log out</a></th>
    </tr>
</table>
<?php
include "connect.php";
if($conn->connect_error){
    die("Error: " . $conn->connect_error);
}
$sql = "SELECT * FROM players";
if($result = $conn->query($sql)){
    $rowsCount = $result->num_rows;
    echo "<p>Rows: $rowsCount</p>";
    echo "<table><tr><th>ID</th><th>First_name</th><th>Last_name</th><th>Gender</th><th>Birth_date</th><th>Position</th><th>Team_id</th><th></th><th></th></tr>";
    foreach($result as $row){
        echo "<tr>";
            echo "<td>" . $row["id"] . "</td>";
            echo "<td>" . $row["first_name"] . "</td>";
            echo "<td>" . $row["last_name"] . "</td>";
            echo "<td>" . $row["gender"] . "</td>";
            echo "<td>" . $row["birth_date"] . "</td>";
            echo "<td>" . $row["position"] . "</td>";
            echo "<td>" . $row["team_id"] . "</td>";
            if('admin' == $_COOKIE["userlevelcookie"]){
            echo "<td><a href='update_players.php?id=" . $row["id"] . "'>Change</a></td>";
            echo "<td><form action='delete_players.php' method='post'>
                        <input type='hidden' name='id' value='" . $row["id"] . "' />
                        <input type='submit' class='button' value='Delete'>
                   </form></td>";
            } else {
                echo "<td></td>";
                echo "<td></td>";
            }
        echo "</tr>";
    }
    echo "</table>";
    $result->free();
} else{
    echo "Error: " . $conn->error;
}
$conn->close();
if('admin' == $_COOKIE["userlevelcookie"])
echo "<table>
    <tr>
        <th><a href='form_players.php'>Add new player</a></th>
    </tr>
</table>"
?>
</div>
</body>
</html>
<!DOCTYPE html>
<html>
<head>
<?php include("font.php"); ?>
<title>Teams</title>
<meta charset="utf-8" />
<link rel="stylesheet" href="css/base.css">
</head>
<body>
<div class="divbgbd">
<h2>List of teams</h2>
<table>
    <tr>
    <th><a href="index.php">Competitions</a></th>
        <th><a href="matches.php">Matches</a></th>
        <th><a href="players.php">Players</a></th>
        <th><?php echo $_COOKIE["usernamecookie"];?></th>
        <th><a href="logout.php">Log out</a></th>
    </tr>
</table>
<?php
include "connect.php";
if($conn->connect_error){
    die("Error: " . $conn->connect_error);
}
$sql = "SELECT * FROM teams";
if($result = $conn->query($sql)){
    $rowsCount = $result->num_rows;
    echo "<p>Rows: $rowsCount</p>";
    echo "<table><tr><th>ID</th><th>Name</th><th>City</th><th>Country</th><th>Level</th><th>Coach_ID</th><th></th><th></th></tr>";
    foreach($result as $row){
        echo "<tr>";
            echo "<td>" . $row["id"] . "</td>";
            echo "<td>" . $row["name"] . "</td>";
            echo "<td>" . $row["city"] . "</td>";
            echo "<td>" . $row["country"] . "</td>";
            echo "<td>" . $row["level"] . "</td>";
            echo "<td>" . $row["coach_id"] . "</td>";
            if('admin' == $_COOKIE["userlevelcookie"]){
            echo "<td><a href='update_teams.php?id=" . $row["id"] . "'>Change</a></td>";
            echo "<td><form action='delete_teams.php' method='post'>
                        <input type='hidden' name='id' value='" . $row["id"] . "' />
                        <input type='submit' class='button' value='Delete'>
                   </form></td>";
            } else {
                echo "<td></td>";
                echo "<td></td>";
            }
        echo "</tr>";
    }
    echo "</table>";
    $result->free();
} else{
    echo "Error: " . $conn->error;
}
$conn->close();
if('admin' == $_COOKIE["userlevelcookie"])
echo "<table>
    <tr>
        <th><a href='form_teams.php'>Add new team</a></th>
    </tr>
</table>"
?>
</div>
</body>
</html>
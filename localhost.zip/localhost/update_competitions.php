<?php 
if('admin' != $_COOKIE["userlevelcookie"]){
    header("Location: intropage.php");
}
?>
<?php
include "connect.php";
if (!$conn) {
    die("Error: " . mysqli_connect_error());
}
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="css/base.css">
<?php include("font.php"); ?>
<title>Updating...</title>
<meta charset="utf-8" />
</head>
<body>
<div class="divbg">
        <div class="regform">
<?php
if($_SERVER["REQUEST_METHOD"] === "GET" && isset($_GET["id"]))
{
    $id = mysqli_real_escape_string($conn, $_GET["id"]);
    $sql = "SELECT * FROM competitions WHERE id = '$id'";
    if($result = mysqli_query($conn, $sql)){
        if(mysqli_num_rows($result) > 0){
            foreach($result as $row){
                $name = $row["name"];
                $location = $row["location"];
                $sdate = $row["start_date"];
                $edate = $row["end_date"];
                $level = $row["level"];
            }
            echo "<h2>Updating data for competitions</h2>
                <form method='post'>
                    <input type='hidden' name='id' value='$id' />
                    <p>Name:</p>
                    <p><input type='text' name='name' value='$name' /></p>
                    <p>Location:</p>
                    <p><input type='text' name='location' value='$location' /></p>
                    <p>Start_Date:</p>
                    <p><input type='text' name='start_date' value='$sdate' /></p>
                    <p>End_Date:</p>
                    <p><input type='text' name='end_date' value='$edate' /></p>
                    <p>Level:</p>
                    <p><input type='text' name='level' value='$level' /></p>
                    <p><input type='submit' class='button' value='Save'></p>
            </form>";
        }
        else{
            echo "<div>Competition not found</div>";
        }
        mysqli_free_result($result);
    } else{
        echo "error: " . mysqli_error($conn);
    }
}
elseif (isset($_POST["id"]) && isset($_POST["name"]) && isset($_POST["location"]) && isset($_POST["start_date"]) && isset($_POST["end_date"]) && isset($_POST["level"])) {
      
    $id = mysqli_real_escape_string($conn, $_POST["id"]);
    $name = mysqli_real_escape_string($conn, $_POST["name"]);
    $location = mysqli_real_escape_string($conn, $_POST["location"]);
    $sdate = mysqli_real_escape_string($conn, $_POST["start_date"]);
    $edate = mysqli_real_escape_string($conn, $_POST["end_date"]);
    $level = mysqli_real_escape_string($conn, $_POST["level"]);
    $sql = "UPDATE competitions SET name = '$name', location = '$location', start_date = '$sdate', end_date = '$edate',  level = '$level' WHERE id = '$id'";
    if($result = mysqli_query($conn, $sql)){
        header("Location: index.php");
    } else{
        echo "Error: " . mysqli_error($conn);
    }
}
else{
    echo "Incorrect data";
}
mysqli_close($conn);
?>
        </div>
    </div>
</body>
</html>
<?php 
if('admin' != $_COOKIE["userlevelcookie"]){
    header("Location: intropage.php");
}
?>
<?php
include "connect.php";
if (!$conn) {
    die("Error: " . mysqli_connect_error());
}
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="css/base.css">
<?php include("font.php"); ?>
<title>Updating...</title>
<meta charset="utf-8" />
</head>
<body>
<div class="divbg">
        <div class="regform">
<?php
if($_SERVER["REQUEST_METHOD"] === "GET" && isset($_GET["id"]))
{
    $id = mysqli_real_escape_string($conn, $_GET["id"]);
    $sql = "SELECT * FROM players WHERE id = '$id'";
    if($result = mysqli_query($conn, $sql)){
        if(mysqli_num_rows($result) > 0){
            foreach($result as $row){
                $first_name = $row["first_name"];
                $last_name = $row["last_name"];
                $gender = $row["gender"];
                $birth_date = $row["birth_date"];
                $position = $row["position"];
                $team_id = $row["team_id"];
            }
            echo "<h2>Updating data for Players</h2>
                <form method='post'>
                    <input type='hidden' name='id' value='$id' />
                    <p>First_name:</p>
                    <p><input type='text' name='first_name' value='$first_name' /></p>
                    <p>Last_name:</p>
                    <p><input type='text' name='last_name' value='$last_name' /></p>
                    <p>Gender:</p>
                    <p><input type='text' name='gender' value='$gender' /></p>
                    <p>Birth_date:</p>
                    <p><input type='text' name='birth_date' value='$birth_date' /></p>
                    <p>Position:</p>
                    <p><input type='text' name='position' value='$position' /></p>
                    <p>Team_id:</p>
                    <p><input type='number' name='team_id' value='$team_id' /></p>
                    <p><input type='submit' class='button' value='Save'></p>
            </form>";
        }
        else{
            echo "<div>Player not found</div>";
        }
        mysqli_free_result($result);
    } else{
        echo "Error: " . mysqli_error($conn);
    }
}
elseif (isset($_POST["id"]) && isset($_POST["first_name"]) && isset($_POST["last_name"]) && isset($_POST["gender"]) && isset($_POST["birth_date"]) && isset($_POST["position"]) && isset($_POST["team_id"])) {
      
    $id = mysqli_real_escape_string($conn, $_POST["id"]);
    $first_name = mysqli_real_escape_string($conn, $_POST["first_name"]);
    $last_name = mysqli_real_escape_string($conn, $_POST["last_name"]);
    $gender = mysqli_real_escape_string($conn, $_POST["gender"]);
    $birth_date = mysqli_real_escape_string($conn, $_POST["birth_date"]);
    $position = mysqli_real_escape_string($conn, $_POST["position"]);
    $team_id = mysqli_real_escape_string($conn, $_POST["team_id"]);
    $sql = "UPDATE players SET first_name = '$first_name', last_name = '$last_name', gender = '$gender', birth_date = '$birth_date', position = '$position', team_id = $team_id WHERE id = '$id'";
    if($result = mysqli_query($conn, $sql)){
        header("Location: players.php");
    } else{
        echo "Error: " . mysqli_error($conn);
    }
}
else{
    echo "Incorrect data";
}
mysqli_close($conn);
?>
        </div>
    </div>
</body>
</html>
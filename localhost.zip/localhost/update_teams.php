<?php 
if('admin' != $_COOKIE["userlevelcookie"]){
    header("Location: intropage.php");
}
?>
<?php
include "connect.php";
if (!$conn) {
    die("Error: " . mysqli_connect_error());
}
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="css/base.css">
<?php include("font.php"); ?>
<title>Updating...</title>
<meta charset="utf-8" />
</head>
<body>
    <div class="divbg">
        <div class="regform">
            <?php
                if($_SERVER["REQUEST_METHOD"] === "GET" && isset($_GET["id"]))
                {
                    $id = mysqli_real_escape_string($conn, $_GET["id"]);
                    $sql = "SELECT * FROM teams WHERE id = '$id'";
                    if($result = mysqli_query($conn, $sql)){
                        if(mysqli_num_rows($result) > 0){
                            foreach($result as $row){
                                $name = $row["name"];
                                $city = $row["city"];
                                $country = $row["country"];
                                $level = $row["level"];
                                $coach_id = $row["coach_id"];
                            }
                            echo "<h2>Updating data for Teams</h2>
                                <form method='post'>
                                    <input type='hidden' name='id' value='$id' />
                                    <p>Name:</p>
                                    <p><input type='text' name='name' value='$name' /></p>
                                    <p>City id:</p>
                                    <p><input type='text' name='city' value='$city' /></p>
                                    <p>Country:</p>
                                    <p><input type='text' name='country' value='$country' /></p>
                                    <p>Level:</p>
                                    <p><input type='text' name='level' value='$level' /></p>
                                    <p>Coach_id:</p>
                                    <p><input type='number' name='coach_id' value='$coach_id' /></p>
                                    <p><input type='submit' class='button' value='Save'></p>
                            </form>";
                        }
                        else{
                            echo "<div>Team not found</div>";
                        }
                        mysqli_free_result($result);
                    } else{
                        echo "Error: " . mysqli_error($conn);
                    }
                }
                 elseif (isset($_POST["id"]) && isset($_POST["name"]) && isset($_POST["city"]) && isset($_POST["country"]) && isset($_POST["level"]) && isset($_POST["coach_id"])) {
                    
                    $id = mysqli_real_escape_string($conn, $_POST["id"]);
                    $name = mysqli_real_escape_string($conn, $_POST["name"]);
                    $city = mysqli_real_escape_string($conn, $_POST["city"]);
                    $country = mysqli_real_escape_string($conn, $_POST["country"]);
                    $level = mysqli_real_escape_string($conn, $_POST["level"]);
                    $coach_id = mysqli_real_escape_string($conn, $_POST["coach_id"]);
                    
                    $sql = "UPDATE teams SET name = '$name', city = '$city', country = '$country', level = '$level', coach_id = $coach_id WHERE id = $id";
                    if($result = mysqli_query($conn, $sql)){
                        header("Location: teams.php");
                    } else{
                        echo "Error: " . mysqli_error($conn);
                    }
                }
                else{
                    echo "Incorrect data";
                }
                mysqli_close($conn);
            ?>
        </div>
    </div>
</body>
</html>